package br.com.apsoo.property;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyApplicationTests {

	@Test
	void contextLoads() {
	}

}
